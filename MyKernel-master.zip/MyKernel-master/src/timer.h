#ifndef TIMER_H
#define TIMER_H

#include "common.h"

void init_timer(u32int freq);
void wait(u32int sec);

#endif
