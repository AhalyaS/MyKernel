#include "screen.h"
#include "timer.h"
#include "kbd.h"

void init_winman(void)
{
	clearscreen();
		
}
