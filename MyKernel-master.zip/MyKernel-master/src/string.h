#include "common.h"

int strlen(char *);
int strcpy(char *,char *);
int strcmp(char *,char *);

void memcpy(u8int *,const u8int *,u32int );
void memset(u8int *,u8int ,u32int );
