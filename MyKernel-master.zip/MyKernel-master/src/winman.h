#ifndef WINMAN_H
#define WINMAN_H

#include "common.h"

typedef struct {

	u16int background;
	
	
};

typedef struct {
	u16int attr;
	u8int row;
	
}taskbar;
#endif
