

int terminal(void);
